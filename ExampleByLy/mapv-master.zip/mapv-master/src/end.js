    Mapv.Layer = Layer;
    window.Mapv = Mapv;

    // add state
    var _image = new Image();
    _image.src = "http://api.map.baidu.com/images/blank.gif?product=jsapi&sub_product=jsapi&v=2.0&sub_product_v=2.0&t=18547002&code=mapv&da_src=mapv&t=" + new Date().getTime();


//annotation}();
