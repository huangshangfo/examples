/**
 * TimeLine Component
 */

function TimeLine(options) {
    Class.call(this);
}

util.inherits(TimeLine, Class);

util.extend(TimeLine.prototype, {
});

var timeLine = new TimeLine({
});
