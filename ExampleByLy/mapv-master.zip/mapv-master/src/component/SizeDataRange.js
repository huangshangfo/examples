/**
 * @file  控制大小值域的类
 * @author nikai (@胖嘟嘟的骨头, nikai@baidu.com)
 */

function SizeDataRange() {
    DataRange.call(this);
}

util.inherits(SizeDataRange, DataRange);

util.extend(SizeDataRange.prototype, {
    
}); // end extend
