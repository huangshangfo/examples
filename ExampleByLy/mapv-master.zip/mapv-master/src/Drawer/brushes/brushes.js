/**
 * @file 笔刷工具
 * @author nikai (@胖嘟嘟的骨头, nikai@baidu.com)
 */
var brushes = {};
